# TaxFraudClicker

A fun incremental clicker game with achievements, upgrades, and jail mechanics!

## Features
- Click to earn currency
- Auto clickers for passive income
- Achievement system
- Upgrade system
- Jail mechanics
- Save game progress

